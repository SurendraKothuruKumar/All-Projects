import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userhead',
  templateUrl: './userhead.component.html',
  styleUrls: ['./userhead.component.css']
})
export class UserheadComponent implements OnInit {
  uname:any;
  constructor() { }

  ngOnInit(): void {
    let user = sessionStorage.getItem('userName');
    this.uname=user;
  }
  isUserLoggedIn() {
    let user = sessionStorage.getItem('userName');
    this.uname=user;
    return !(user === null)
  }
}
