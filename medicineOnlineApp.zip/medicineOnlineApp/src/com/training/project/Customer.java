package com.training.project;

import java.util.ArrayList;

public class Customer extends Medicine implements PharmacySevice {
  public String name;
  public String address;
  public long phno;

  ArrayList<Customer> cu = new ArrayList<Customer>();

    
  public String getCname() {
    return name;
  }

  /*
 * Setter method
 */
  public void setCname(String name) {
    this.name = name;
  }

  public String getAddress() {
    return address;
  }

  /*
  * Setter method
  */
  public void setAddress(String address) {
    this.address = address;
  }
  
  public long getPhno() {
    return phno;
  }

  /*
  * Setter method
  */
  public void setPhno(long phno) {
    this.phno = phno;
  }

  /*
 * Constructor method
 */
  
  public Customer(String name, String address, long phno, int Num,
        String Name, float price)
  {
    super();
    this.name = Name;
    this.num = Num;
    this.price = price;
    this.name = name;
    this.address = address;
    this.phno = phno;
  }

    /*
     * Method To Display The Customer Details ..
     */
  public void CustomerDetails(ArrayList<Customer> c2) {

    for (Customer d : c2) {
      System.out.println(
                d.getNum() + "  " + d.getName() + "  " + d.getPrice());
    }
  }

}
