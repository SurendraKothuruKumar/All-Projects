package com.training;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class medicineServlat
 */
@WebServlet("/medicineServlat")
public class medicineServlat extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public medicineServlat() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    if (request.getParameter("username").equals("admin") && request.getParameter("password").equals("admin")) {
	        response.sendRedirect("home.html");
	       
	        }else {
	            response.getWriter().append("<h1 style = \"color:red\">Sorry Invalid Details</h1><a href =\"./index.html\">Click here to login</a>");
	        }
	}

}
