package com.example.DemoProject.service;

import java.util.List;

import com.example.DemoProject.model.User;

public interface RegisterService {
	
		public  List findAll();

		public  User findById(int id);

		public  User save(com.example.DemoProject.model.User m);

		public  Boolean deleteById(int id);

		public User findByUserNameAndPassword(String tempUserName, String tempPass);

		public User findUserByUserName(String tempName);


	

}
