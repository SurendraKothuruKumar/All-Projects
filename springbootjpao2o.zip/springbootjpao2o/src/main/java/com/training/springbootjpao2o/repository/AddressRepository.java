package com.training.springbootjpao2o.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.training.springbootjpao2o.model.Address;
@Repository
public interface AddressRepository extends CrudRepository<Address, Integer> {

}
