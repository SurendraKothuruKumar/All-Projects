package com.training.springbootjpao2o.model;

import javax.persistence.Entity;
import javax.persistence.Id;



@Entity

public class Address {
	@Id
	private int id;
	private String city;
	private String state;
	private String country;
	private AddressType type;
	public Address(AddressType type) {
		super();
		this.type = type;
	}
	public AddressType getType() {
		return type;
	}
	public void setType(AddressType type) {
		this.type = type;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Address(int id, String city, String state, String country) {
		super();
		this.id = id;
		this.city = city;
		this.state = state;
		this.country = country;
	}
	public Address() {
		super();
	}
	
	
}
