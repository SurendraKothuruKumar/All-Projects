package com.training;

/*
 * Importing All classes used ...
 */

import java.util.Scanner;
import java.util.Vector;

/**
 * @author
 *
 */
public class Main extends Medicines implements MediApp {

	public static void main(String Args[]) throws Exception {
		/*
		 * Adding The Details to The List
		 */
		Fever fever = new Fever(0, null, 0);
		fever.f.add(new Fever(1, "Paracetamol", 36.5f));
		fever.f.add(new Fever(2, "Aspirin", 15.7f));
		fever.f.add(new Fever(3, "Acephen", 43.5f));
		fever.f.add(new Fever(4, "Mapap", 26.0f));
		fever.f.add(new Fever(5, "Motrin", 45.9f));
		fever.f.add(new Fever(6, "Naproxen", 55.2f));
		fever.f.add(new Fever(7, "Advil", 66.7f));
		fever.f.add(new Fever(8, "Bayeraspirin", 24.1f));
		fever.f.add(new Fever(9, "Aspergum", 31.0f));
		fever.f.add(new Fever(10, "Aspirtab", 56.4f));

		/*
		 * Adding The Details to The List
		 */
		Cough cough = new Cough(0, null, 0);
		cough.c.add(new Cough(1, "Codeine", 19.1f));
		cough.c.add(new Cough(2, "Tessalon perles", 57.6f));
		cough.c.add(new Cough(3, "Promethegan", 14.0f));
		cough.c.add(new Cough(4, "Hydromet", 22.4f));
		cough.c.add(new Cough(5, "Hydrocodone", 18.8f));
		cough.c.add(new Cough(6, "Benadryl", 53.4f));
		cough.c.add(new Cough(7, "Guaifenasin", 26.3f));
		cough.c.add(new Cough(8, "Hycodan", 20.1f));
		cough.c.add(new Cough(9, "Delsym", 33.0f));
		cough.c.add(new Cough(10, "Tessalon", 48.0f));
		cough.c.add(new Cough(11, "Lortab", 30.0f));

		/*
		 * Adding The Details to The List
		 */
		Cold cold = new Cold(0, null, 0);
		cold.cl.add(new Cold(1, "Ibuprofen", 29.5f)); // Relieves Inflammation
		cold.cl.add(new Cold(2, "Acetaminophen", 09.2f)); // Pain Killer
		cold.cl.add(new Cold(3, "Dextromethorphan", 57.4f)); // Helps in releasing pain
		cold.cl.add(new Cold(4, "Decongestant", 99.0f)); // inflamed nasal passage
		cold.cl.add(new Cold(5, "Antihistamines", 89.2f));
		cold.cl.add(new Cold(6, "Diphenhydramine", 25.1f));
		cold.cl.add(new Cold(7, "Phenylephrine", 19.7f));
		cold.cl.add(new Cold(8, "Caffeine", 10.7f));
		cold.cl.add(new Cold(9, "Mucinex", 22.0f));
		cold.cl.add(new Cold(10, "Sambucol", 35.0f));
		cold.cl.add(new Cold(11, "Vicks", 10.0f)); // Reduces cough

		Customer customer = new Customer(null, null, 0, 0, null, 0.0f);

		/*
		 * Creating An Scanner Object
		 */

		Scanner sc = new Scanner(System.in);
		String choice = "0";
		String choice1 = "0";
		float total = 0;
		String name = "";
		String mname = "";
		String Address = "";
		long Phno = 0;

		/**
		 * User Will Choose The Symptoms He/she has
		 */

		System.out.println("---Welcome to MediApp---");

		while (true) {
			System.out.println("1.Buy/order the Medicines");
			System.out.println("2.Add/Update/Delete the Medicines");
			System.out.println("3.calculate/billing the Medicines");
			System.out.println("4.Quit");
			choice1 = sc.next();
			switch (choice1) {
			case "1":
				int x = 1;
				while (x == 1) {

					System.out.println("Choose The Symptom You Have");
					System.out.println("1.Fever\n" + "2.Cough\n" + "3.Cold");
					choice = sc.next();
					try {
						Integer.parseInt(choice);

					} catch (NumberFormatException me) {
						System.out.println("Try Integer Values 1,2,3..for Input");

					}
					// System.out.println("continue");

					// Comparing The Choice Of user with the available cases..
					Vector<Object> vector = new Vector<Object>();
					String s;

					float price = 0;
					int Num = 0;

					int i = 1;
					int bt = 0;

					// Vector Object Is Used To Get The Selection Of Medicines..

					java.util.Enumeration<Object> e = vector.elements();
					switch (choice) {
					case "1":

						// Displaying all Medicines Available

						fever.Display();

						System.out.println("Please Select The Medicine U want..");
						/*
						 * Untill User Selects The Medicines While Loop Occurs
						 */

						while (i <= 2) {
							try {
								s = (String) sc.next();
								vector.add(s);
								i++;

								for (Fever d : fever.f) {

									if (d.getName().equalsIgnoreCase(s)) {
										bt = bt + 1;
									}
								}
								if (bt == 0) {
									throw new Exception("you have not entered The Corect medicine Name");
								}
								bt = 0;

							}

							catch (NullPointerException ne) {
								System.out.println("Null Pointer Exception");
							} catch (Exception ec) {
								System.out.println(ec.getMessage());
								System.out.println("Continue...");
							}

							continue;

						}

						System.out.println("Enter Your Name");
						name = sc.next();
						System.out.println("Enter Your Address");
						Address = sc.next();
						System.out.println("Enter Your Phone Number");
						Phno = sc.nextLong();

						/*
						 * Comparing The User Medicines and Available Medicines..
						 */

						while (e.hasMoreElements()) {
							String temp = (String) e.nextElement();

							for (Fever d : fever.f) {

								if (d.getName().equalsIgnoreCase(temp)) {
									mname = temp;
									Num = d.getNum();
									price = +d.getPrice();

									// Adding The Customer Selcted Medicines To Customer Deatails..

									customer.c.add(new Customer(name, Address, Phno, Num, mname, price));

									total = total + d.getPrice();


								} else
									continue;

							}

						}
						// printing the Total Rupees Added for User

						break;

					case "2":
						// Displaying all Medicines Available

						cough.Display();
						System.out.println("Please Select The Medicine U want..");
						/*
						 * Untill User Selects The Medicines While Loop Occurs
						 */

						while (i <= 2) {
							try {
								s = (String) sc.next();
								vector.add(s);
								i++;

								for (Cough d : cough.c) {

									if (d.getName().equalsIgnoreCase(s)) {
										bt = bt + 1;
									}
								}
								if (bt == 0) {
									throw new Exception("you have not entered The Corect medicine Name");
								}
								bt = 0;

							} catch (Exception ec) {
								System.out.println(ec.getMessage());
								System.out.println("Continue...");
							}

							continue;

						}

						System.out.println("Enter Your Name");
						name = sc.next();
						System.out.println("Enter Your Address");
						Address = sc.next();
						System.out.println("Enter Your Phone Number");
						Phno = sc.nextLong();
						/*
						 * Comparing The User Medicines and Available Medicines..
						 */

						while (e.hasMoreElements()) {
							String temp = (String) e.nextElement();

							for (Cough d : cough.c) {

								if (d.getName().equalsIgnoreCase(temp)) {
									mname = temp;
									Num = d.getNum();
									price = +d.getPrice();

									// Adding The Customer Selcted Medicines To Customer Deatails.

									customer.c.add(new Customer(name, Address, Phno, Num, mname, price));

									total = total + d.getPrice();

								} else
									continue;

							}

						}
						// printing the Total Rupees Added for User

						break;

					case "3":
						// Displaying all Medicines Available

						cold.Display();
						System.out.println("Please Select The Medicine U want..");
						/*
						 * Untill User Selects The Medicines While Loop Occurs
						 */

						while (i <= 2) {
							try {
								s = (String) sc.next();
								vector.add(s);
								i++;

								for (Fever d : fever.f) {

									if (d.getName().equalsIgnoreCase(s)) {
										bt = bt + 1;
									}
								}
								if (bt == 0) {
									throw new Exception("you have not entered The Corect medicine Name");
								}
								bt = 0;

							} catch (Exception ec) {
								System.out.println(ec.getMessage());
								System.out.println("Continue...");
							}

							continue;

						}

						System.out.println("Enter Your Name");
						name = sc.next();
						System.out.println("Enter Your Address");
						Address = sc.next();
						System.out.println("Enter Your Phone Number");
						Phno = sc.nextLong();

						/*
						 * Comparing The User Medicines and Available Medicines..
						 */

						while (e.hasMoreElements()) {
							String temp = (String) e.nextElement();

							for (Cold d : cold.cl) {

								if (d.getName().equalsIgnoreCase(temp)) {
									mname = temp;
									Num = d.getNum();
									price = +d.getPrice();

									// Adding The Customer Selcted Medicines To Customer Deatails.
									customer.c.add(new Customer(name, Address, Phno, Num, mname, price));

									total = total + d.getPrice();

								} else
									continue;

							}

						}


					}

					System.out.println("do you want to buy ?");
					System.out.println("1.yes 2.No");
					x = sc.nextInt();
				}

				break;

			case "2":
				System.out.println("1.Add Medicines");
				System.out.println("2.Update Medicines");
				System.out.println("3.delete Medicines");

				String choice2 = "0";
				choice2 = sc.next();
				switch (choice2) {
				case "1":
					System.out.println("1.Fever details \n 2.cold Details \n 3. cough details");
					String choice3 = "0";
					choice3 = sc.next();
					switch (choice3) {
					case "1":
						System.out.println("Enter the medicine name");
						String addName = sc.next();

						System.out.println("Enter the medicine Price");
						float addPrice = sc.nextFloat();

						fever.addMedicine(addName, addPrice);
						fever.Display();
						break;
					case "2":
						System.out.println("Enter the medicine name");
						String addName1 = sc.next();

						System.out.println("Enter the medicine Price");
						float addPrice1 = sc.nextFloat();
						cold.addMedicine(addName1, addPrice1);
						cold.Display();
						break;
					case "3":
						System.out.println("Enter the medicine name");
						String addName2 = sc.next();

						System.out.println("Enter the medicine Price");
						float addPrice2 = sc.nextFloat();
						cough.addMedicine(addName2, addPrice2);
						cough.Display();
						break;
					}
					break;
				case "2":
					System.out.println("1.Fever details \n 2.cold Details \n 3. cough details");
					String choice4 = "0";
					choice4 = sc.next();
					switch (choice4) {
					case "1":
						fever.Display();
						System.out.println("Enter the medicine number u want to update");
						int unum = sc.nextInt();
						System.out.println("Enter the medicine name to update");
						String uname = sc.next();

						System.out.println("Enter the medicine Price to update");
						float uprice = sc.nextFloat();

						fever.updateMedicine(unum, uname, uprice);

						fever.Display();
						break;
					case "2":
						cold.Display();
						System.out.println("Enter the medicine number u want to update");
						int unum1 = sc.nextInt();
						System.out.println("Enter the medicine name to update");
						String uname1 = sc.next();

						System.out.println("Enter the medicine Price to update");
						float uprice1 = sc.nextFloat();

						cold.updateMedicine(unum1, uname1, uprice1);

						cold.Display();
						break;
					case "3":
						cough.Display();
						System.out.println("Enter the medicine number u want to update");
						int unum2 = sc.nextInt();
						System.out.println("Enter the medicine name to update");
						String uname2 = sc.next();

						System.out.println("Enter the medicine Price to update");
						float uprice2 = sc.nextFloat();

						cough.updateMedicine(unum2, uname2, uprice2);

						cough.Display();
						break;
					}
					break;
				case "3":
					System.out.println("1.Fever details \n 2.cold Details \n 3. cough details");
					String choice5 = "0";
					choice5 = sc.next();
					int number = 0;
					switch (choice5) {
					case "1":
						fever.Display();
						System.out.println("Enter the medicine number u want to delete");
						number = sc.nextInt();
						fever.deleteMedicine(number);

						fever.Display();
						break;
					case "2":
						cold.Display();
						System.out.println("Enter the medicine number u want to delete");
						number = sc.nextInt();
						cold.deleteMedicine(number);

						cold.Display();
						break;

					case "3":
						cough.Display();
						System.out.println("Enter the medicine number u want to delete");
						number = sc.nextInt();
						cough.deleteMedicine(number);


						cough.Display();
						break;


					}

					break;

				}
				break;
			case "3":

				System.out.println("Name" + "  " + "Address" + "  " + "Phno");
				System.out.println("-----------------------------");
				System.out.println(name + " " + Address + " " + Phno);
				System.out.println("------------------------");
				System.out.println("Num" + "   " + " Medicine" + "   " + "Price");
				customer.CustomerDetails(customer.c);
				System.out.println("Total---------------------------" + total);

				break;
			case "4":
				System.out.println("Thank You !!!");
				System.exit(0);
				break;

			}
			System.out.println("Thank You !!!");
		}
	}
}
