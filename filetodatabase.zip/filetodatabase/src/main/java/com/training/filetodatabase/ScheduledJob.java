package com.training.filetodatabase;

import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

@Component
public class ScheduledJob extends QuartzJobBean {

	@Autowired
	private EmployeeService emps;
	public static final Logger LOGGER = LoggerFactory.getLogger(ScheduledJob.class);

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		// TODO Auto-generated method stub
		LOGGER.debug("QuartzJob is running......");  
		try {
			emps.storedata();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
