import { Component, OnInit } from '@angular/core';
import { PolicyService } from '../../service/policy.service';
import { Router } from '@angular/router';
import { Policy } from 'src/app/model/policy';

@Component({
  selector: 'app-policylist',
  templateUrl: './policylist.component.html',
  styleUrls: ['./policylist.component.css']
})
export class PolicylistComponent implements OnInit {
  loading: boolean = false;
  policyList: any;
  policytemp: any;
  PolicytempList: Policy[] = [];
  policy:Policy = new Policy;
  constructor(private policyserv: PolicyService, private router: Router) {
    this.policyserv.getAllPolicy()
      .subscribe((data: any) => {
        this.policyList = data;
        this.PolicytempList = this.policyList;
        console.log(this.PolicytempList);
        this.loading = false;
      }, ((error: any) => {
        console.log(error)
        this.loading = true;
        return null;
      }), () => {
        this.loading = false;
      });
  }

  ngOnInit(): void {
  }
 
}
