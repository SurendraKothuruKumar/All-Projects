package com.training;
/*
 * An Interface..
 */
public interface Medplus {

	/*
	 * Display Method
	 */
	public void Display();
	
    
	
	
}
