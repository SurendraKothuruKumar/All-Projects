import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Policy } from 'src/app/model/policy';
import { FormBuilder, Validators } from '@angular/forms';
import { PolicyService } from 'src/app/service/policy.service';

@Component({
  selector: 'app-editpolicy',
  templateUrl: './editpolicy.component.html',
  styleUrls: ['./editpolicy.component.css']
})
export class EditpolicyComponent implements OnInit {
  policyId:any;
  currdata:any;
  policy:Policy=new Policy;
  message!: string;
  policyList: string[] = ['Healthcare','Lic', 'Vehicle', 'Home' , 'Property'];
  constructor(private activatedRoute: ActivatedRoute,private formBuilder: FormBuilder, private Policyservice: PolicyService, private router: Router) {
    this.policyId=activatedRoute.snapshot.paramMap.get("policyId");
   console.log(this.policyId);
   this.Policyservice.getPolicyById(this.policyId).subscribe((data: any) => { //success
  
    this.currdata=data;

    this.policy=this.currdata;

    this.policyUpdateForm = this.formBuilder.group(

        {

        policyId: [this.policy.policyId, Validators.compose([Validators.required])],

        policyName: [this.policy.policyName, Validators.compose([Validators.required])],

        policyDesc: [this.policy.policyDesc, Validators.compose([Validators.required])],

        policyType: [this.policy.policyType, Validators.compose([Validators.required])],

        sumAssured: [this.policy.sumAssured, Validators.compose([Validators.required])],

        premium: [this.policy.premium, Validators.compose([Validators.required])],


        duration: [this.policy.duration, Validators.compose([Validators.required])],

        companyName: [this.policy. companyName, Validators.compose([Validators.required])],
        }

        )

    }, ((error: any) => { // error

    alert("Error in Updating employee details.");

    console.log(error)

    return null;

    }), () => { //complete

    });

}
policyUpdateForm = this.formBuilder.group(

{


  policyId: [this.policy.policyId, Validators.compose([Validators.required])],

  policyName: [this.policy.policyName, Validators.compose([Validators.required])],

  policyDesc: [this.policy.policyDesc, Validators.compose([Validators.required])],

  policyType: [this.policy.policyType, Validators.compose([Validators.required])],

  sumAssured: [this.policy.sumAssured, Validators.compose([Validators.required])],

  premium: [this.policy.premium, Validators.compose([Validators.required])],


  duration: [this.policy.duration, Validators.compose([Validators.required])],

  companyName: [this.policy. companyName, Validators.compose([Validators.required])],

}

)

ngOnInit(): void {
}
onSubmit() {

if (!this.policyUpdateForm.invalid) {

this.Policyservice.updatePolicy(this.policyUpdateForm.getRawValue()).subscribe((data: any) => { //success

alert("Policy is successfully updated.");

this.router.navigateByUrl("/policylist");

}, ((error: any) => { // error

alert("Error in updating employee details.");

console.log(error)

return null;

}), () => { //complete

});

}

}

}

