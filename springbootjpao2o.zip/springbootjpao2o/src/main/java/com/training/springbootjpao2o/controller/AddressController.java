package com.training.springbootjpao2o.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.training.springbootjpao2o.model.Address;

import com.training.springbootjpao2o.service.AddressService;


@Controller

public class AddressController {
	
	@Autowired
	AddressService addService;
	private List<Address> add;
	int id;
	
	@GetMapping("/edit")
	public String showEditProductPage(ModelMap model, HttpServletRequest request) {
		 id = Integer.parseInt(request.getParameter("id"));
		
		 add= addService.getAllAddress();
		for (Address a : add) {

			if (a.getId() == id) {

				model.addAttribute("Employee", new Address(a.getId(), a.getCity(), a.getCountry(), a.getState()));

			}

		}
		return "edit";
	}
	@PostMapping("/edit")
	public String editEmployeeDetails(@ModelAttribute("Address") Address empl, ModelMap model) {



	addService.updateEmployee(empl, id);



	return "redirect:/";



	}
	@GetMapping("/delete")
	 public String deleteEmployee(ModelMap model, HttpServletRequest request) {
		id = Integer.parseInt(request.getParameter("id"));
		 System.out.println(id);
		 addService.deleteEmployee(id);
		return "redirect:/";
	 }

}
