package com.training.springbootjpao2o.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.training.springbootjpao2o.model.Employee;
import com.training.springbootjpao2o.repository.EmployeeRepository;
@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeRepository empRepository;

	@Override
	public List<Employee> getAllEmployees() {
	return (List<Employee>) empRepository.findAll();
	}

	@Override
	public void save(Employee employee) {
		// TODO Auto-generated method stub
		empRepository.save(employee);
		
	}
	@Override
	public Employee get(int id) {
		// TODO Auto-generated method stub
		return empRepository.findById(id).get();
	}

	public void updateEmployee(Employee empl, int id) {
		// TODO Auto-generated method stub
		Employee emp = empRepository.findById(id).get();



		emp.setName(empl.getName());
		emp.setGender(empl.getGender());
		emp.setSalary(empl.getSalary());
		empRepository.save(emp);
		
	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		this.empRepository.deleteById(id);
		
	}
	

	
}
