package com.training.project;

import java.util.ArrayList;

/*
 * An Interface..
 */
public interface PharmacySevice {
  public void Display();
  
  public void CustomerDetails(ArrayList<Customer> c);
  
  public void addMedicine(String name, float price);
  
  public void updateMedicine(int number, String name, float price);
  
  public void deleteMedicine(int number);

}