import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BulkpayComponent } from './bulkpay.component';

describe('BulkpayComponent', () => {
  let component: BulkpayComponent;
  let fixture: ComponentFixture<BulkpayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BulkpayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BulkpayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
