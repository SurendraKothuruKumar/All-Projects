package com.training.springbootform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootformApplicationTests {

	@Test
	void contextLoads() {
	}

}
