package com.training;

import java.util.ArrayList;

public class Customer extends Medicines implements Medplus {
	
	public String name;
	public String Address;
	public long Phno;

	ArrayList<Customer> c = new ArrayList<Customer>();

	/*
	 * Getter method
	 */
	public String getCname() {
		return name;
	}

	/*
	 * Setter method
	 */
	public void setCname(String name) {
		Name = name;
	}

	public String getAddress() {
		return Address;
	}

	/*
	 * Setter method
	 */
	public void setAddress(String address) {
		Address = address;
	}

	public long getPhno() {
		return Phno;
	}

	/*
	 * Setter method
	 */
	public void setPhno(long phno) {
		Phno = phno;
	}

	/*
	 * Constructor method
	 */
	public Customer(String name, String address, long phno, int Num, String Name, float price) {
		super();
		this.Name = Name;
		this.Num = Num;
		this.Price = price;
		this.name = name;
		this.Address = address;
		this.Phno = phno;
	}

	/*
	 * Method To Display The Customer Details ..
	 */
	public void CustomerDetails() {

		for (Customer d : c) {

			System.out.println(d.getCname() + "  " + d.getAddress() + "  " + d.getPhno() + " " + d.getNum() + "  "
					+ d.getName() + "  " + d.getPrice());
		}
	}

}
