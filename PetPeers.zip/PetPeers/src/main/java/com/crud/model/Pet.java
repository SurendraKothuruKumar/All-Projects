package com.crud.model;
import java.io.Serializable;


public class Pet implements Serializable {

        /**
         * 
         */
        private static final long serialVersionUID = 1L;
        private int id;
        private String petname;
        private String petcolor;
        private String breed;
        

        /**
         * 
         */
        public Pet() {
            super();
        }



        



        /**
         * @return the username
         */
        

        public Pet( String petname, String petcolor, String breed) {
            super();
            
            this.petname = petname;
            this.petcolor = petcolor;
            this.breed = breed;
        }



        public Pet(int id, String petname, String petcolor, String breed) {
            super();
            this.id = id;
            this.petname = petname;
            this.petcolor = petcolor;
            this.breed = breed;
        }







        @Override
        public String toString() {
            return "Pet [id=" + id + ", petname=" + petname + ", petcolor="
                    + petcolor + ", breed=" + breed + "]";
        }



        public int getId() {
            return id;
        }



        public void setId(int id) {
            this.id = id;
        }



        public String getPetname() {
            return petname;
        }



        public void setPetname(String petname) {
            this.petname = petname;
        }



        public String getPetcolor() {
            return petcolor;
        }



        public void setPetcolor(String petcolor) {
            this.petcolor = petcolor;
        }



        public String getBreed() {
            return breed;
        }



        public void setBreed(String breed) {
            this.breed = breed;
        }



        /**
         * @param username the username to set
         */
        

        

    }

