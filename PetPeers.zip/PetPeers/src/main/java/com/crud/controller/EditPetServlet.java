package com.crud.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.crud.dao.PetDAO;
import com.crud.dao.PetDAOImpl;
import com.crud.model.Pet;

/**
 * Servlet implementation class EditPetServlet
 */
@WebServlet("/EditPetServlet")
public class EditPetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger LOGGER = LogManager.getLogger(EditPetServlet.class);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditPetServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    LOGGER.debug("GetEdit Method is called");
	    int id =Integer.parseInt(request.getParameter("id"));
        PetDAO petDAO = new PetDAOImpl();

        Pet pet= petDAO.findPet(id);
        request.setAttribute("pet", pet);
        RequestDispatcher rd = request
        .getRequestDispatcher("editPet.jsp");
        rd.forward(request, response);
        LOGGER.debug("GetEdit Method ended succesfully");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    LOGGER.debug("PostEdit Method is called");
	    int id =Integer.parseInt(request.getParameter("id"));
        String petname = request.getParameter("petname");
        String petcolor = request.getParameter("petcolor");
        String breed = request.getParameter("breed");

        Pet pet = new Pet(id,petname, petcolor,breed);
        LOGGER.info("Pet is succesfully added to the petlist");
        System.out.println(pet);
        PetDAO petDAO = new PetDAOImpl();
        if(petDAO.update(pet)) {
        response.sendRedirect("./PetServlet");
        }else {
        RequestDispatcher rd = request
        .getRequestDispatcher("addPet-error.jsp");
        rd.forward(request, response);
        }
        LOGGER.debug("PostEdit Method is Ended");
	}

}
