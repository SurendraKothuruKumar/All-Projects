package com.crud.dao;

import java.sql.SQLException;
import java.util.List;

import com.crud.model.User;

public interface UserDAO {
    public void getConnection();

    public void closeConnection();

    public List<User> findUsers();

    public boolean addUser(User user);

    public User findUser(String name);
    
    public boolean update(User user) throws SQLException;
    
    public boolean delete(int id) throws SQLException;
}
