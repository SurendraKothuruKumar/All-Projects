package com.training.springbootjpao2o.model;

public enum AddressType {
	WORK, PERMENANT, CURRENT
}
