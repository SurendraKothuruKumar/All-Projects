package com.training.springbootjpao2o.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.training.springbootjpao2o.model.Address;
import com.training.springbootjpao2o.model.Employee;
import com.training.springbootjpao2o.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	EmployeeService empService;
	private List<Employee> emp;
	int id;

	@GetMapping("/")
	public ModelAndView getAllEmployees() {
		return new ModelAndView("home", "empList", empService.getAllEmployees());
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveProduct(@ModelAttribute("product") Employee employee) {
		empService.save(employee);

		return "redirect:/";
	}

	@GetMapping("/edit")
	public String showEditProductPage(ModelMap model, HttpServletRequest request) {
		 id = Integer.parseInt(request.getParameter("id"));
		
		emp = empService.getAllEmployees();
		for (Employee b : emp) {

			if (b.getId() == id) {

				model.addAttribute("Employee", new Employee(b.getId(), b.getName(), b.getGender(), b.getSalary()));

			}

		}
		return "edit";
	}
	@PostMapping("/edit")
	public String editEmployeeDetails(@ModelAttribute("Employee") Employee empl, ModelMap model) {



	empService.updateEmployee(empl, id);



	return "redirect:/";



	}
	@GetMapping("/delete")
	 public String deleteEmployee(ModelMap model, HttpServletRequest request) {
		id = Integer.parseInt(request.getParameter("id"));
		 System.out.println(id);
		 empService.deleteEmployee(id);
		return "redirect:/";
	 }

}
