package com.training.filetodatabase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FiletodatabaseApplication {

	public static void main(String[] args) {
		 
		SpringApplication.run(FiletodatabaseApplication.class, args);
	}

}
