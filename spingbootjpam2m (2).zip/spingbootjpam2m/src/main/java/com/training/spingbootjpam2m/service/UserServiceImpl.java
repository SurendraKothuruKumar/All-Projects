package com.training.spingbootjpam2m.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.training.spingbootjpam2m.model.User;
import com.training.spingbootjpam2m.repository.UserRepository;

public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepository userRepository;

	@Override
	public List<User> getUserList() {
		// TODO Auto-generated method stub
		return (List<User>) userRepository.findAll();
	}

}
