package com.training.springbootjpao2o;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootjpao2oApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springbootjpao2oApplication.class, args);
	}

}
