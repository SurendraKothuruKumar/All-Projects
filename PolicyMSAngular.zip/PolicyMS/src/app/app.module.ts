import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AdminhomeComponent } from './admin/adminhome/adminhome.component';
import { AddpolicyComponent } from './admin/addpolicy/addpolicy.component';
import { EditpolicyComponent } from './admin/editpolicy/editpolicy.component';
import { HomeComponent } from './home/home.component';
import { UserhomeComponent } from './user/userhome/userhome.component';

import { PolicylistComponent } from './admin/policylist/policylist.component';
import { PaypolicyComponent } from './user/paypolicy/paypolicy.component';
import { UserheadComponent } from './user/userhead/userhead.component';
import { BulkpayComponent } from './user/bulkpay/bulkpay.component';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    HeaderComponent,
    FooterComponent,
    AdminhomeComponent,
    AddpolicyComponent,
    EditpolicyComponent,
    HomeComponent,
    UserhomeComponent,
    UserhomeComponent,
    PolicylistComponent,
    PaypolicyComponent,
    UserheadComponent,
    BulkpayComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
