package com.training.springbootform.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.training.springbootform.model.Book;

@Controller
@RequestMapping("/Book")
public class BookController {
	static List<Book> bookList = new ArrayList<>();
	@GetMapping("/createBook")
	public String addBook(ModelMap model) {
		
		model.addAttribute("Book",new Book());
		return "createBookPage";
	}
	@PostMapping("/createBook")
	public String addBookDetails(@Valid @ModelAttribute("Book") Book Book,BindingResult result) throws Exception{
		if(!result.hasErrors()){
			bookList.add(Book);
			return "redirect:/Book/getBooks";
		}
		throw new Exception("Error in Book details");
		//return "createBookPage";
	}
	@GetMapping("/getBooks")
	public ModelAndView showBooks() {
		return new ModelAndView("listBooksPage","bookList",bookList);
	}

}
