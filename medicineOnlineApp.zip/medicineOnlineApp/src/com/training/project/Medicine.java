package com.training.project;

import java.util.ArrayList;

public class Medicine implements PharmacySevice {
  
  public String name;
  public float price;
  public int num;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public float getPrice() {
    return price;
  }

  public void setPrice(float price) {
    this.price = price;
  }

  public int getNum() {
    return num;
  }

  public void setNum(int num) {
    this.num = num;
  }

  public void Display() {
    System.out.println(getNum() + "\t\t" + getName() + "\t\t" + getPrice() + "\n");
  }

  @Override
  public void CustomerDetails(ArrayList<Customer> c) {
    // TODO Auto-generated method stub

  }
  @Override
  public void addMedicine(String name, float price) {
    // TODO Auto-generated method stub

  }

  @Override
  public void updateMedicine(int number, String name, float price) {
    // TODO Auto-generated method stub

  }

  @Override
  public void deleteMedicine(int number) {
    // TODO Auto-generated method stub

  }

}

class Covid extends Medicine {

  ArrayList<Covid> c = new ArrayList<Covid>();
  int Num;

  public Covid(int Num, String Name, float price) {

		this.name = Name;
		this.price = price;
		this.Num = Num;

	}

	/*
	 * Getter method
	 */
	public int getNum() {
		return Num;
	}

	/*
	 * Setter method
	 */
	public void setNum(int num) {
		Num = num;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.training.Medicines#Display()
	 */
	public void Display() {
	    
		System.out.println("Sl Num" + "\t\t" + "Name" + "\t\t\t" + "Price" + "\n");

		for (Covid d : c) {
			System.out.println(d.getNum() + "\t\t" + d.getName() + "\t\t\t" + d.getPrice() + "\n");
		}
		
	}
public void deleteMedicine(int number) {
    
        
        c.remove(--number);
        
    }

    public void updateMedicine(int number, String name, float price) {
        // TODO Auto-generated method stub
        
        for (Covid fv : c) {
            if (fv.getNum() == number) {
                fv.setName(name);
                fv.setPrice(price);
            }
        }
        
    }

    public void addMedicine(String name, float price) {
        
        int number = 0;
        for (Covid g : c) {
            number = g.getNum();

        }

        c.add(new Covid(++number, name, price));
        
    }

}

class Headache extends Medicine {

	ArrayList<Headache> h = new ArrayList<Headache>();
	int Num;

	public Headache(int Num, String name, float price) {
		this.name = name;
		this.price = price;
		this.Num = Num;
	}

	/*
	 * Getter method
	 */
	public int getNum() {
		return Num;
	}

	/*
	 * Setter method
	 */
	public void setNum(int num) {
		Num = num;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.training.Medicines#Display()
	 */
	public void Display() {
	    
		System.out.println("Sl Num" + "\t\t" + "Name" + "\t\t\t" + "Price" + "\n");
		for (Headache d : h) {
			System.out.println(d.getNum() + "\t\t" + d.getName() + "\t\t" + d.getPrice() + "\n");
		}
		


	}
	public void deleteMedicine(int number) {
        // TODO Auto-generated method stub
	    
        h.remove(--number);
        
    }

    public void updateMedicine(int number, String name, float price) {
        
        // TODO Auto-generated method stub
        for (Headache cg : h) {
            if (cg.getNum() == number) {
                cg.setName(name);
                cg.setPrice(price);
            }
        }
        
    }

    public void addMedicine(String name, float price) {
        
        
        // TODO Auto-generated method stub
        int number = 0;
        for (Headache g : h) {
            number = g.getNum();

        }

        h.add(new Headache(++number, name, price));
        
    }

}

class Fever extends Medicine {

	ArrayList<Fever> f = new ArrayList<Fever>();
	int Num;

	public Fever(int Num, String name, float price) {
		this.name = name;
		this.price = price;
		this.Num = Num;
	}

	/*
	 * Getter method
	 */
	public int getNum() {
		return Num;
	}
	/*
	 * Setter method
	 */

	public void setNum(int num) {
		Num = num;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.training.Medicines#Display()
	 */
	public void Display() {
	    
		System.out.println("Sl Num" + "\t\t" + "Name" + "\t\t\t" + "Price" + "\n");
		for (Fever d : f) {
			System.out.println(d.getNum() + "\t\t" + d.getName() + "\t\t" + d.getPrice() + "\n");
		}
		
	}
public void deleteMedicine(int number) {
        
    
    f.remove(--number);
    
    }

    public void updateMedicine(int number, String name, float price) {
        // TODO Auto-generated method stub
        
        for (Fever fv : f) {
            if (fv.getNum() == number) {
                fv.setName(name);
                fv.setPrice(price);
            }
        }
        
    }

    public void addMedicine(String name, float price) {
        
        int number = 0;
        for (Fever g : f) {
            number = g.getNum();

        }

        f.add(new Fever(++number, name, price));
        
    }

}
