package com.training;

import java.util.ArrayList;

/*
 * An Interface..
 */
public interface MediApp {

	/*
	 * Display Method
	 */
	public void Display();

	public void addMedicine(String name, float price);

	public void updateMedicine(int number, String name, float price);

	public void deleteMedicine(int number);

	public void CustomerDetails(ArrayList<Customer> c);
	
}
