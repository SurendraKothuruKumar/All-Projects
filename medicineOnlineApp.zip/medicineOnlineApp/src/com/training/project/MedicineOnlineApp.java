package com.training.project;

/*
 * Importing All classes used ...
 */

import java.util.Scanner;
import java.util.Vector;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;




public class MedicineOnlineApp extends Medicine implements PharmacySevice {
    static Logger LOGGER = LogManager.getLogger(MedicineOnlineApp.class);
    

    public static void main(String Args[]) throws Exception {
        LOGGER.debug("My Application started............");
      
    Covid covid = new Covid(0, null, 0);
    covid.c.add(new Covid(1, "Lopinavir", 36.5f));
    covid.c.add(new Covid(2, "Ritronavir", 15.7f));
    covid.c.add(new Covid(3, "Camostat", 43.5f));
    covid.c.add(new Covid(4, "Famotidine", 26.0f));
    covid.c.add(new Covid(5, "Motrin", 45.9f));

    Headache headache = new Headache(0, null, 0);
    headache.h.add(new Headache(1, "ibuprofen", 19.1f));
    headache.h.add(new Headache(2, "asprin", 57.6f));
    headache.h.add(new Headache(3, "naproxen", 14.0f));
    headache.h.add(new Headache(4, "caffeine", 22.4f));
    headache.h.add(new Headache(5, "Hydrocodone", 18.8f));
    
    Fever fever = new Fever(0, null, 0);
    fever.f.add(new Fever(1, "Paracetamol", 36.5f));
    fever.f.add(new Fever(2, "Advil", 66.7f));
    fever.f.add(new Fever(3, "Acephen", 43.5f));
    fever.f.add(new Fever(4, "Mapap", 26.0f));
    fever.f.add(new Fever(5, "Motrin", 45.9f));
    fever.f.add(new Fever(6, "Naproxen", 55.2f));

    Customer customer = new Customer(null, null, 0, 0, null, 0.0f);


    @SuppressWarnings("resource")
    Scanner sc = new Scanner(System.in);
    String choice = "0";
    String choice1 = "0";
    float total = 0;
    String name = "";
    String mname = "";
    String address = "";
    long phno = 0;

    System.out.println("---Welcome to MedicineOnlineApp---");

    while (true) {
      System.out.println("1.Buy/order the Medicines");
      System.out.println("2.Add/Edit the Medicines");
      System.out.println("3.calculate/Display the Medicines");
      System.out.println("4.Quit");
      choice1 = sc.next();
      switch (choice1) {
        case "1":
          int x = 1;
          while (x == 1) {

            System.out.println("Choose The Symptom You Have");
            System.out.println("1.Covid\n" + "2.Headache\n" + "3.Fever");
            choice = sc.next();
            try {
              Integer.parseInt(choice);
            
            } catch (NumberFormatException me) {
              System.out.println("Try Integer Values 1,2,3..for Input");
            
            }
            // Comparing The Choice Of user with the available cases..
            Vector<Object> vector = new Vector<Object>();
            String s;
            
            float price = 0;
            int num = 0;
            int i = 1;
            int bt = 0;
            
            java.util.Enumeration<Object> e = vector.elements();
            switch (choice) {
              case "1":
                LOGGER.info("Calling Display method for covid medicines");
                covid.Display();
                System.out.println("Please Select The Medicine U want..");
            
                while (i <= 2) {
                  try {
                    s = (String) sc.next();
                    vector.add(s);
                    i++;
                    
                    for (Covid d : covid.c) {
                    
                      if (d.getName().equalsIgnoreCase(s)) {
                        bt = bt + 1;
                      }
                    }
                    if (bt == 0) {
                      throw new Exception("you have not entered The Corect medicine Name");
                    }
                    bt = 0;
                  }

                  catch (NullPointerException ne) {
                    System.out.println("Null Pointer Exception");
                  } catch (Exception ec) {
                    System.out.println(ec.getMessage());
                    System.out.println("Continue...");
                  }

                  continue;

                }

                System.out.println("Enter Your Name");
                name = sc.next();
                System.out.println("Enter Your Address");
                address = sc.next();
                System.out.println("Enter Your Phone Number");
                phno = sc.nextLong();
                
                LOGGER.info("adding the Customer Selcted Medicines To Customer Deatails");
                while (e.hasMoreElements()) {
                  String temp = (String) e.nextElement();

                  for (Covid d : covid.c) {
                    
                    if (d.getName().equalsIgnoreCase(temp)) {
                      mname = temp;
                      num = d.getNum();
                      price = +d.getPrice();
                    
                      customer.cu.add(new Customer(name, address, phno, num, mname,price));
                      total = total + d.getPrice();
                    } 
                    
                  }
                }
                break;

              case "2":
                LOGGER.info("Calling Display method for headache medicines");
                headache.Display();
                System.out.println("Please Select The Medicine U want..");

                while (i <= 2) {
                  try {
                    s = (String) sc.next();
                    vector.add(s);
                    i++;

                    for (Headache d : headache.h) {

                      if (d.getName().equalsIgnoreCase(s)) {
                        bt = bt + 1;
                      }
                    }
                    if (bt == 0) {
                      throw new Exception("you have not entered The Corect medicine Name");
                    }
                    bt = 0;

                  } 
                  catch (Exception ec) {
                    System.out.println(ec.getMessage());
                    System.out.println("Continue...");
                  }

                  continue;

                }

                System.out.println("Enter Your Name");
                name = sc.next();
                System.out.println("Enter Your Address");
                address = sc.next();
                System.out.println("Enter Your Phone Number");
                phno = sc.nextLong();
                LOGGER.info("adding the Customer Selcted Medicines To Customer Deatails");
                while (e.hasMoreElements()) {
                  String temp = (String) e.nextElement();

                  for (Headache d : headache.h) {

                    if (d.getName().equalsIgnoreCase(temp)) {
                      mname = temp;
                      num = d.getNum();
                      price = +d.getPrice();

                      customer.cu.add(new Customer(name, address, phno, num, mname, price));

                      total = total + d.getPrice();

                    } else {
                      continue;
                    }
                
                  }

                }

                break;

              case "3":
                LOGGER.info("Calling Display method for fever medicines");
                fever.Display();
                System.out.println("Please Select The Medicine U want..");

                while (i <= 2) {
                  try {
                    s = (String) sc.next();
                    vector.add(s);
                    i++;

                    for (Covid d : covid.c) {

                      if (d.getName().equalsIgnoreCase(s)) {
                        bt = bt + 1;
                      }
                    }
                    if (bt == 0) {
                      throw new Exception("you have not entered The Corect medicine Name");
                    }
                    bt = 0;

                  } catch (Exception ec) {
                    System.out.println(ec.getMessage());
                    System.out.println("Continue...");
                  }

                  continue;

                }

                System.out.println("Enter Your Name");
                name = sc.next();
                System.out.println("Enter Your Address");
                address = sc.next();
                System.out.println("Enter Your Phone Number");
                phno = sc.nextLong();
                LOGGER.info("adding the Customer Selcted Medicines To Customer Deatails");
                while (e.hasMoreElements()) {
                  String temp = (String) e.nextElement();

                  for (Fever d : fever.f) {

                    if (d.getName().equalsIgnoreCase(temp)) {
                      mname = temp;
                      num = d.getNum();
                      price = +d.getPrice();
                      customer.cu.add(new Customer(name, address, phno, num, mname, price));

                      total = total + d.getPrice();

                    } else {
                      continue;
                    }

                  }

                }
              default:
                break;

            }

            System.out.println("do you want to buy ?");
            System.out.println("1.yes 2.No");
            x = sc.nextInt();
          }

          break;

        case "2":
          System.out.println("1.Add Medicines");
          System.out.println("2.Update Medicines");
          System.out.println("3.delete Medicines");
          String choice2 = "0";
          choice2 = sc.next();
          switch (choice2) {
            case "1":
              System.out.println("1.Covid details \n 2.Fever Details \n 3. Headache details");
              String choice3 = "0";
              choice3 = sc.next();
              switch (choice3) {
                case "1":
                  System.out.println("Enter the medicine name");
                  String addName = sc.next();

                  System.out.println("Enter the medicine Price");
                  float addPrice = sc.nextFloat();
                  LOGGER.info("adding the given medicines");
                  covid.addMedicine(addName, addPrice);
                  LOGGER.info("Calling Display method after adding into covid medicines");
                  covid.Display();
                  break;
                case "2":
                  System.out.println("Enter the medicine name");
                  String addName1 = sc.next();

                  System.out.println("Enter the medicine Price");
                  float addPrice1 = sc.nextFloat();
                  LOGGER.info("adding the given medicines");
                  fever.addMedicine(addName1, addPrice1);
                  LOGGER.info("Calling Display methodafter adding into cold medicines");
                  fever.Display();
                  break;
                case "3":
                  System.out.println("Enter the medicine name");
                  String addName2 = sc.next();

                  System.out.println("Enter the medicine Price");
                  float addPrice2 = sc.nextFloat();
                  LOGGER.info("adding the given medicines");
                  headache.addMedicine(addName2, addPrice2);
                  LOGGER.info("Calling Display method after adding into cough medicines");
                  headache.Display();
                  break;                
                default:
                  break;
              }
              break;
            case "2":
              System.out.println("1.Covid details \n 2.Fever Details \n 3. Headache details");
              String choice4 = "0";
              choice4 = sc.next();
              switch (choice4) {
                case "1":
                  covid.Display();
                  System.out.println("Enter the medicine number u want to update");
                  int num = sc.nextInt();
                  System.out.println("Enter the medicine name to update");
                  String uname = sc.next();

                  System.out.println("Enter the medicine Price to update");
                  float price = sc.nextFloat();

                  LOGGER.info("updating the medicines");
                  covid.updateMedicine(num, uname, price);
                  LOGGER.info("Calling Display method after updating covid medicines");

                  covid.Display();
                  break;
                case "2":
                  fever.Display();
                  System.out.println("Enter the medicine number u want to update");
                  int num1 = sc.nextInt();
                  System.out.println("Enter the medicine name to update");
                  String name1 = sc.next();

                  System.out.println("Enter the medicine Price to update");
                  float price1 = sc.nextFloat();

                  LOGGER.info("updating the medicines");
                  fever.updateMedicine(num1, name1, price1);
                  LOGGER.info("Calling Display method after updating fever medicines");

                  fever.Display();
                  break;
                case "3":
                  headache.Display();
                  System.out.println("Enter the medicine number u want to update");
                  int num2 = sc.nextInt();
                  System.out.println("Enter the medicine name to update");
                  String name2 = sc.next();
                
                  System.out.println("Enter the medicine Price to update");
                  float price2 = sc.nextFloat();

                  LOGGER.info("updating the medicines");
                  headache.updateMedicine(num2, name2, price2);
                  LOGGER.info("Calling Display method after updating headache medicines");

                  headache.Display();
                  break;
            default:
                break;
              }
              break;
            case "3":
              System.out.println("1.Covid details \n 2.Fever Details \n 3. Headache details");
              String choice5 = "0";
              choice5 = sc.next();
              int number = 0;
              switch (choice5) {
                case "1":
                  covid.Display();
                  System.out.println("Enter the medicine number u want to delete");
                  number = sc.nextInt();
                  LOGGER.info("deleting the medicines");
                  covid.deleteMedicine(number);
                  LOGGER.info("Calling Display method after deleting the covid medicines");
                  covid.Display();
                  break;
                case "2":
                  fever.Display();
                  System.out.println("Enter the medicine number u want to delete");
                  number = sc.nextInt();
                  LOGGER.info("deleting the medicines");
                  fever.deleteMedicine(number);
                  LOGGER.info("Calling Display method after deleting the fever medicines");
                
                  fever.Display();
                  break;

                case "3":
                  headache.Display();
                  System.out.println("Enter the medicine number u want to delete");
                  number = sc.nextInt();
                  LOGGER.info("deleting the medicines");
                  fever.deleteMedicine(number);
                  LOGGER.info("Calling Display method after deleting the headache medicines");
                
                
                  headache.Display();
                  break;
                default:
                  break;


              }
        default:
            break;
          }
          
          break;
        case "3":

          System.out.println("Name" + "  " + "Address" + "  " + "Phno");
          System.out.println("-----------------------------");
          System.out.println(name + " " + address + " " + phno);
          System.out.println("------------------------");
          System.out.println("Num" + "   " + " Medicine" + "   " + "Price");
          LOGGER.info("displaying the  Customer Deatails");
          customer.CustomerDetails(customer.cu);
          System.out.println("Total---------------------------" + total);

          break;
                    
        case "4":
          System.out.println("Thank You !!!");
          LOGGER.debug("mediapp application ended....");
          System.exit(0);
          break;
        default:
          break;
    

      }
      System.out.println("Thank You !!!");
    }	
  }
}
