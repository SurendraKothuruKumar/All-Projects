package com.training;

import java.util.ArrayList;
import java.util.Scanner;

public class Medicines implements MediApp {
	public String Name;
	public float Price;
	public int Num;

	/*
	 * Getter method
	 */
	public String getName() {
		return Name;
	}

	/*
	 * Setter method
	 */
	public void setName(String name) {
		Name = name;
	}

	/*
	 * Getter method
	 */
	public float getPrice() {
		return Price;
	}

	/*
	 * Setter method
	 */
	public void setPrice(float price) {
		Price = price;
	}

	/*
	 * Getter method
	 */
	public int getNum() {
		return Num;
	}

	/*
	 * Setter method
	 */
	public void setNum(int num) {
		Num = num;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.training.Medplus#Display()
	 */
	public void Display() {
		System.out.println(getNum() + "\t\t" + getName() + "\t\t" + getPrice() + "\n");
	}

	@Override
	public void CustomerDetails(ArrayList<Customer> c) {
		// TODO Auto-generated method stub

	}

	@Override
	public void addMedicine(String name, float price) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateMedicine(int number, String name, float price) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteMedicine(int number) {
		// TODO Auto-generated method stub

	}

}

class Fever extends Medicines {
	Scanner sc = new Scanner(System.in);
	ArrayList<Fever> f = new ArrayList<Fever>();
	int Num;

	public Fever(int Num, String Name, float price) {

		this.Name = Name;
		this.Price = price;
		this.Num = Num;

	}

	/*
	 * Getter method
	 */
	public int getNum() {
		return Num;
	}

	/*
	 * Setter method
	 */
	public void setNum(int num) {
		Num = num;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.training.Medicines#Display()
	 */
	public void Display() {
		System.out.println("Sl Num" + "\t\t" + "Name" + "\t\t\t" + "Price" + "\n");

		for (Fever d : f) {
			System.out.println(d.getNum() + "\t\t" + d.getName() + "\t\t\t" + d.getPrice() + "\n");
		}
	}

	public void deleteMedicine(int number) {
		
		f.remove(--number);
	}

	public void updateMedicine(int number, String name, float price) {
		// TODO Auto-generated method stub

		for (Fever fv : f) {
			if (fv.getNum() == number) {
				fv.setName(name);
				fv.setPrice(price);
			}
		}
	}

	public void addMedicine(String name, float price) {
		int number = 0;
		for (Fever g : f) {
			number = g.getNum();

		}

		f.add(new Fever(++number, name, price));
	}

}

class Cough extends Medicines {

	ArrayList<Cough> c = new ArrayList<Cough>();
	int Num;

	public Cough(int Num, String name, float price) {
		this.Name = name;
		this.Price = price;
		this.Num = Num;
	}

	/*
	 * Getter method
	 */
	public int getNum() {
		return Num;
	}

	/*
	 * Setter method
	 */
	public void setNum(int num) {
		Num = num;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.training.Medicines#Display()
	 */
	public void Display() {
		System.out.println("Sl Num" + "\t\t" + "Name" + "\t\t\t" + "Price" + "\n");
		for (Cough d : c) {
			System.out.println(d.getNum() + "\t\t" + d.getName() + "\t\t" + d.getPrice() + "\n");
		}

	}

	public void deleteMedicine(int number) {
		// TODO Auto-generated method stub
		c.remove(--number);
	}

	public void updateMedicine(int number, String name, float price) {
		// TODO Auto-generated method stub
		for (Cough cg : c) {
			if (cg.getNum() == number) {
				cg.setName(name);
				cg.setPrice(price);
			}
		}
	}

	public void addMedicine(String name, float price) {
		// TODO Auto-generated method stub
		int number = 0;
		for (Cough g : c) {
			number = g.getNum();

		}

		c.add(new Cough(++number, name, price));
	}

}

class Cold extends Medicines {

	ArrayList<Cold> cl = new ArrayList<Cold>();
	int Num;

	public Cold(int Num, String name, float price) {
		this.Name = name;
		this.Price = price;
		this.Num = Num;
	}

	/*
	 * Getter method
	 */
	public int getNum() {
		return Num;
	}
	/*
	 * Setter method
	 */

	public void setNum(int num) {
		Num = num;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.training.Medicines#Display()
	 */
	public void Display() {
		System.out.println("Sl Num" + "\t\t" + "Name" + "\t\t\t" + "Price" + "\n");
		for (Cold d : cl) {
			System.out.println(d.getNum() + "\t\t" + d.getName() + "\t\t" + d.getPrice() + "\n");
		}
	}

	public void deleteMedicine(int number) {
		// TODO Auto-generated method stub
		cl.remove(--number);
	}

	public void updateMedicine(int number, String name, float price) {
		// TODO Auto-generated method stub
		for (Cold c : cl) {
			if (c.getNum() == number) {
				c.setName(name);
				c.setPrice(price);
			}
		}
	}

	public void addMedicine(String name, float price) {
		// TODO Auto-generated method stub
		int number = 0;
		for (Cold g : cl) {
			number = g.getNum();

		}

		cl.add(new Cold(++number, name, price));
	}

}
