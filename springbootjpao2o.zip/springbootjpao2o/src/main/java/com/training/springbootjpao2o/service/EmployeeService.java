package com.training.springbootjpao2o.service;

import java.util.List;

import com.training.springbootjpao2o.model.Employee;

public interface EmployeeService {
	List<Employee> getAllEmployees();
	public void save(Employee employee);
	public Employee get(int id);
	void updateEmployee(Employee empl, int id);
	void deleteEmployee(int id);
	

}
