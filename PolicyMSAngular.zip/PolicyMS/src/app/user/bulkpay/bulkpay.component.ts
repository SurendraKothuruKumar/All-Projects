import { Component, OnInit } from '@angular/core';
import { Payment } from 'src/app/model/payment';
import { PolicyService } from 'src/app/service/policy.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-bulkpay',
  templateUrl: './bulkpay.component.html',
  styleUrls: ['./bulkpay.component.css']
})
export class BulkpayComponent implements OnInit {
  userId:any;
  policyId: any;
  cpolicyId: any;
  loading: boolean = false;
  paymentList: any;
  paymenttemp: any;
  PaymenttempList: Payment[] = [];
  payment:Payment = new Payment;
  constructor(private policyserv: PolicyService, private router: Router,private activatedRoute: ActivatedRoute,) {
    
    this.cpolicyId= sessionStorage.getItem('cpolicyId');
    this.userId= sessionStorage.getItem('userId');
    this.policyserv.getBulkPayments(this.userId,this.cpolicyId)
      .subscribe((data: any) => {
        this.paymentList = data;
        this.PaymenttempList = this.paymentList;
        console.log(this.PaymenttempList);
        this.loading = false;
      }, ((error: any) => {
        console.log(error)
        this.loading = true;
        return null;
      }), () => {
        this.loading = false;
      });
  }

  ngOnInit(): void {
  }
 onSubmit(){


    this.policyserv.updatePayments(this.userId,this.cpolicyId).subscribe((data: any) => { //success
    
    alert("Payments successfully updated.");
    
    this.router.navigateByUrl("/userhome");
    
    }, ((error: any) => { // error
    
    alert("Error in updating payment details.");
    
    console.log(error)
    
    return null;
    
    }), () => { //complete
    
    });
    
    }
    
    }
    
 

