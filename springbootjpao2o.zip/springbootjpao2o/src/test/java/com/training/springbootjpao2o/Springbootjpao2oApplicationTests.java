package com.training.springbootjpao2o;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootjpao2oApplicationTests {

	@Test
	void contextLoads() {
	}

}
