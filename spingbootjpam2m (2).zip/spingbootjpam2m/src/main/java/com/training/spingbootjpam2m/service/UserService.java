package com.training.spingbootjpam2m.service;

import java.util.List;

import com.training.spingbootjpam2m.model.User;

public interface UserService {
	public List<User> getUserList();

}
