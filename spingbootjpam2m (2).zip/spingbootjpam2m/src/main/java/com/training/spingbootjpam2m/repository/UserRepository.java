package com.training.spingbootjpam2m.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.training.spingbootjpam2m.model.User;

@Repository

public interface UserRepository extends CrudRepository<User, Integer> {

}
