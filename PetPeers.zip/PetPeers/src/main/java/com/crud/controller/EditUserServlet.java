package com.crud.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.crud.dao.UserDAO;
import com.crud.dao.UserDAOImpl;
import com.crud.model.User;

/**
 * Servlet implementation class EditUserServlet
 */
@WebServlet("/EditUserServlet")
public class EditUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    static Logger LOGGER = LogManager.getLogger(EditUserServlet.class);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditUserServlet() {
        super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
        LOGGER.debug("GetEdit Method is called");
        String name = request.getParameter("name");
        UserDAO userDAO = new UserDAOImpl();
        
        User user = userDAO.findUser(name);
        
        request.setAttribute("user", user);
            RequestDispatcher rd = request
                    .getRequestDispatcher("editUser.jsp");
            rd.forward(request, response);
        LOGGER.debug("GetEdit Method ended succesfully");
        
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LOGGER.debug("PostEdit Method is called");
        int id=Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String address = request.getParameter("address");
        String mobileno = request.getParameter("mobileno");
        User user = new User(id,name,address,mobileno);
        LOGGER.info("User is succesfully added to the petlist");
        UserDAO userDAO=new UserDAOImpl();
            try {
                userDAO.update(user);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            response.sendRedirect("./UserServlet");
        LOGGER.debug("PostEdit Method ended succesfully");
    }


}
