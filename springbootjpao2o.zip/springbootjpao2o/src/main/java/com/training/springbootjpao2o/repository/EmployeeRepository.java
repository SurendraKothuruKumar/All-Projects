package com.training.springbootjpao2o.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.training.springbootjpao2o.model.Employee;
@Repository
public interface EmployeeRepository extends CrudRepository<Employee, Integer> {

}
