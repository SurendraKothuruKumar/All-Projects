package com.training.spingbootjpam2m;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spingbootjpam2mApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spingbootjpam2mApplication.class, args);
	}

}
