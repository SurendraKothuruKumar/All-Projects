import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['./adminhome.component.css']
})
export class AdminhomeComponent implements OnInit {

  uname!: string | null;
  constructor() { }

  ngOnInit() {
  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('user.userName')
    this.uname=user;
    return !(user === null)
  }


}
