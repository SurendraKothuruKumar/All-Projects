package com.training.springbootjpao2o.service;

import java.util.List;

import com.training.springbootjpao2o.model.Address;

public interface AddressService {

	List<Address> getAllAddress();

	void updateEmployee(Address empl, int id);

	void deleteEmployee(int id);

}
