package com.crud.dao;

import java.sql.SQLException;
import java.util.List;

import com.crud.model.Pet;

public interface PetDAO {
    public void getConnection();

    public void closeConnection();

    public List<Pet> findPet();

    public boolean addPet(Pet pet);

    public Pet findPet(int id);
    
    public boolean update(Pet pet);
    
    public boolean deletePet(int id) throws SQLException;
}
