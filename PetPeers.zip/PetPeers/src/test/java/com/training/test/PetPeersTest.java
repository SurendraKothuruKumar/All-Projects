package com.training.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.crud.dao.PetDAO;
import com.crud.dao.PetDAOImpl;
import com.crud.dao.UserDAO;
import com.crud.dao.UserDAOImpl;
import com.crud.model.Pet;
import com.crud.model.User;

public class PetPeersTest {

	@Test
	public void test() {
		String name = "sunny";
        String address = "chennai";
        String mobileno = "78457578";
        
        User user = new User(name,address,mobileno);
        UserDAO userDAO = new UserDAOImpl();
        assertTrue(userDAO.addUser(user));
	}
	@Test
	public void test1() {
		String petname = "Snoopy";
        String petcolor = "white";
        String breed = "italian";
        
        Pet pet = new Pet(petname, petcolor, breed);
        PetDAO petDAO = new PetDAOImpl();
        assertTrue(petDAO.addPet(pet));
	}
	
	
	

}
