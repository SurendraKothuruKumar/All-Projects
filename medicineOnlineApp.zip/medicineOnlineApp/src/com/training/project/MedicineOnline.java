/**
 * 
 */
package com.training.project;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.util.*;

/**
 * @author kothurusurend.kumar
 *
 */
class MedicineOnline {
    MedicineOnlineApp medicine = new MedicineOnlineApp();
    Scanner sc = new Scanner(System.in);

    @Test
    void test() {
        fail("Not yet implemented");
    }

}
