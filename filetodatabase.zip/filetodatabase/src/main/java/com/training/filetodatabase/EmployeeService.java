package com.training.filetodatabase;

import java.util.HashMap;
import java.util.List;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;
import java.io.*;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository empRepo;

	private static final String NAME_OF_JOB = "myJob";
	private static final String NAME_OF_GROUP = "mygroup";
	private static final String NAME_OF_TRIGGER = "triggerStart";
	int TIME_INTERVAL = 1;

	@Autowired
	Scheduler scheduler;

	public static final Logger LOGGER = LoggerFactory.getLogger(EmployeeService.class);

	boolean fileStatus = true;

	boolean count = true;

	List<File> sources;

	public void storedata() throws Exception {
		LOGGER.debug("EmployeeService  is running......");
		LOGGER.info("storedData() method is called .....");
		try {

			for (File file : sources) {
				System.out.println("file : " + file);

				ObjectMapper mapper = new ObjectMapper();
				TypeReference<List<Employee>> mapType = new TypeReference<List<Employee>>() {
				};
				InputStream is = TypeReference.class.getResourceAsStream("/json/" + file.getName());

				List<Employee> empList = mapper.readValue(is, mapType);
				List<Employee> tempList = (List<Employee>) empRepo.findAll();

				for (Employee b : empList) {
					fileStatus = true;
					count = true;
					if (empRepo.findAllById(b.getId()) != null) {
						for (Employee c : tempList) {

							if ((b.getId() == c.getId())) {
								if ((b.getName().equalsIgnoreCase(c.getName())) && (b.getSalary() == c.getSalary())) {
									fileStatus = false;

								} else {
									count = false;
									empRepo.saveAll(empList);
									LOGGER.info("Updated the data and added in database......");
									System.out.println("Updated the  list  successfully...........");
									System.out.println("Modifieded the  list of records of file ..." + file.getName());
								}
							}
						}
					} else if (empRepo.findAllById(b.getId()) == null) {
						empRepo.saveAll(empList);
						LOGGER.info("Added the data in database......");
						System.out.println("Added the  record list  successfully...........");

					}
				}
				if (fileStatus == false && count == true) {
					LOGGER.info("The file is already readed......");
					System.out.println("File has already read...........");
				}

			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private List<File> getAllFilesFromResource(String folder) throws URISyntaxException, IOException {
		LOGGER.debug("Getting all the Resources file ......");
		ClassLoader classLoader = getClass().getClassLoader();

		URL resource = classLoader.getResource(folder);

		List<File> collect = Files.walk(Paths.get(resource.toURI())).filter(Files::isRegularFile).map(x -> x.toFile())
				.collect(Collectors.toList());

		return collect;
	}

	public void schedule() throws URISyntaxException, IOException {

		try {
			scheduler.start();
			EmployeeService app = new EmployeeService();
			sources = app.getAllFilesFromResource("json");

		} catch (SchedulerException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		JobDetail jobInstance = JobBuilder.newJob(ScheduledJob.class).withIdentity(NAME_OF_JOB, NAME_OF_GROUP).build();

		Trigger triggerNew = TriggerBuilder.newTrigger().withIdentity(NAME_OF_TRIGGER, NAME_OF_GROUP)
				.withSchedule(
						SimpleScheduleBuilder.simpleSchedule().withIntervalInHours(TIME_INTERVAL).repeatForever())
				.build();

		try {
			scheduler.scheduleJob(jobInstance, triggerNew);
		} catch (SchedulerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
