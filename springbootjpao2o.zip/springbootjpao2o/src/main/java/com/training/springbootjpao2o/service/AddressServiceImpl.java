package com.training.springbootjpao2o.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.training.springbootjpao2o.model.Address;

import com.training.springbootjpao2o.repository.AddressRepository;


public class AddressServiceImpl implements AddressService {
	
	@Autowired
	AddressRepository addRepository;

	@Override
	public List<Address> getAllAddress() {
		// TODO Auto-generated method stub
		return (List<Address>) addRepository.findAll();
	}

	@Override
	public void updateEmployee(Address empl, int id) {
		// TODO Auto-generated method stub
		
		Address add = addRepository.findById(id).get();



		add.setState(empl.getCity());
		add.setCountry(empl.getCountry());
		add.setState(empl.getState());
		addRepository.save(add);
		
	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		this.addRepository.deleteById(id);
		
	}

}
