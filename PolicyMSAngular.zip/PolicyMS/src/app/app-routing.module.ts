import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { AdminhomeComponent } from './admin/adminhome/adminhome.component';
import { AddpolicyComponent } from './admin/addpolicy/addpolicy.component';
import { HomeComponent } from './home/home.component';
import { UserhomeComponent } from './user//userhome/userhome.component';
import { PolicylistComponent } from './admin/policylist/policylist.component';
import { EditpolicyComponent } from './admin/editpolicy/editpolicy.component';
import { PaypolicyComponent } from './user/paypolicy/paypolicy.component';
import { BulkpayComponent } from './user/bulkpay/bulkpay.component';
const routes: Routes = [
  
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'register',
    component:RegistrationComponent
  },
  {
    path:'adminhome',
    component:AdminhomeComponent
  },
  {
    path:'addpolicy',
    component:AddpolicyComponent
  },
  {
    path:'header',
    component: HeaderComponent
  },
  {
    path:'home',
    component: HomeComponent
  },
  {
    path:'policylist',
    component: PolicylistComponent
  },
  {
    path:'userhome',
    component: UserhomeComponent
  },
  {
    path:'editpolicy/:policyId',
    component: EditpolicyComponent
  },
 
  {
    path:'paypolicy/:policyId',
    component: PaypolicyComponent
  },
  {
    path:'bulkpay',
    component: BulkpayComponent
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
