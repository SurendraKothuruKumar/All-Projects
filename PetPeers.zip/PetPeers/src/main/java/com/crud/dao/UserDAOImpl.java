package com.crud.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.crud.controller.DeleteUserServlet;
import com.crud.model.User;

public class UserDAOImpl implements UserDAO {
    static Logger LOGGER = LogManager.getLogger(DeleteUserServlet.class);
    static Connection conn;

    @Override
    public void getConnection() {
        LOGGER.debug("Get Connection is started");
        if (conn == null) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/crud", "root", "root");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        LOGGER.debug("Get Connection is Ended");
    }

    @Override
    public void closeConnection() {
        LOGGER.debug("close Connection is started");
        try {
            conn.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        LOGGER.debug("close Connection is ended");

    }

    @Override
    public List<User> findUsers() {
        getConnection();
        List<User> userList = new ArrayList<>();
        LOGGER.info("Creating the List");
        String queryStr = "select * from User";
        LOGGER.info("SQL Query to select user");
        Statement stmt;
        try {
            stmt = conn.createStatement();

            // 3.Execute SQL Statements
            // 4.GET ResultSet
            ResultSet rs = stmt.executeQuery(queryStr);

            while (rs.next()) {
                User tempUser = new User();

                tempUser.setId(rs.getInt("id"));
                tempUser.setName(rs.getString("name"));
                tempUser.setAddress(rs.getString("address"));
                tempUser.setMobileno(rs.getString("mobileno"));
                userList.add(tempUser);
                LOGGER.info("Details added to list succesfully");
            }
            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userList;
    }

    @Override
    public boolean addUser(User user) {
        LOGGER.debug("Add user method started");
        getConnection();
        PreparedStatement prestmt1;
        try {
            prestmt1 = conn
                    .prepareStatement("insert into User(name,address,mobileno) values(?,?,?) ");
            LOGGER.info("SQL Query for inserting values");

            //prestmt1.setInt(1, user.getId());// 1�specifies�the�first�parameter�in�the�query
            prestmt1.setString(1, user.getName());
            LOGGER.error("name should be String");
            prestmt1.setString(2, user.getAddress());
            LOGGER.error("Address should be String");
            prestmt1.setString(3, user.getMobileno());
            LOGGER.error("mobile number should be String");
            prestmt1.executeUpdate();
            System.out.println("Inserted a record successfully");
            prestmt1.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    public boolean update(User user) throws SQLException {
        LOGGER.debug("update user is started");
        getConnection();
        PreparedStatement prestmt1;

            prestmt1 = conn.prepareStatement(
                    "update User set name=?, address=?, mobileno=? where id = ? ");
            LOGGER.info("SQL Query for update");
 
            prestmt1.setInt(4, user.getId());
            prestmt1.setString(1, user.getName());
            LOGGER.error("name should be String");
            prestmt1.setString(2, user.getAddress());
            LOGGER.error("Address should be String");
            prestmt1.setString(3, user.getMobileno());
            LOGGER.error("mobilenumber should be String");
            prestmt1.executeUpdate();
            System.out.println("Updated the record successfully");
            prestmt1.close();
            return true;
       }

    @Override
    public User findUser(String name) {
        LOGGER.debug("Finding user is started");
        getConnection();
        String queryStr = "select * from User where name='" + name + "'";
        LOGGER.info("SQL Query for finding user");
        Statement stmt;
        try {
            stmt = conn.createStatement();

            // 3.Execute SQL Statements
            // 4.GET ResultSet
            ResultSet rs = stmt.executeQuery(queryStr);
            User tempUser = new User();
            while (rs.next()) {

                tempUser.setId(rs.getInt("id"));
                tempUser.setName(rs.getString("name"));
                tempUser.setAddress(rs.getString("address"));
                tempUser.setMobileno(rs.getString("mobileno"));

            }
            stmt.close();
            return tempUser;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        LOGGER.debug("find ended is ended");
        return null;
    }
    public boolean delete(int id) throws SQLException{
        getConnection();
        PreparedStatement prestmt1=conn.prepareStatement("delete from User where id=?;");
        LOGGER.info("Delete query for deleting the record");
        prestmt1.setInt(1, id);
        prestmt1.executeUpdate();
        System.out.println("Deleted the record successfully");
        prestmt1.close();
        return true;
    }
}
