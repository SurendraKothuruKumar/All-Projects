package com.crud.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.crud.dao.PetDAO;
import com.crud.dao.PetDAOImpl;

/**
 * Servlet implementation class DeletePetServlet
 */
@WebServlet("/DeletePetServlet")
public class DeletePetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger LOGGER = LogManager.getLogger(DeletePetServlet.class);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeletePetServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    LOGGER.debug("Delete Method called");
	    PetDAO petDAO=new PetDAOImpl();
        int id = Integer.parseInt(request.getParameter("id"));
        try {
            petDAO.deletePet(id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        response.sendRedirect("./PetServlet");
        LOGGER.debug("Delete Method Ended");
	}

}
