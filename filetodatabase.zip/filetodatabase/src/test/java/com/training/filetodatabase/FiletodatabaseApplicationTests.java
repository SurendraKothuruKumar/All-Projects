package com.training.filetodatabase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiletodatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
