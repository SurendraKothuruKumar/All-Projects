package com.crud.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.crud.controller.DeleteUserServlet;
import com.crud.model.Pet;

public class PetDAOImpl implements PetDAO {
    static Logger LOGGER = LogManager.getLogger(DeleteUserServlet.class);
    static Connection conn;
    Statement statement = null;

    @Override
    public void getConnection() {
        LOGGER.debug("Get Connection is started");
        if (conn == null) {
            LOGGER.info("checking the connection");
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/crud", "root", "root");
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        LOGGER.debug("Get Connection is Ended");
    }

    @Override
    public void closeConnection() {
        LOGGER.debug("close Connection is started");
        try {
            conn.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        LOGGER.debug("Get Connection is Ended");
    }

    @Override
    public List<Pet> findPet() {
    	Connection conn = null;
        getConnection();
        List<Pet> petList = new ArrayList<>();
        LOGGER.info("Creating the List");
        String queryStr = "select * from pet";
        LOGGER.info("SQL Query to select pet");
        Statement stmt;
        try {
            stmt = conn.createStatement();

            // 3.Execute SQL Statements
            // 4.GET ResultSet
            ResultSet rs = stmt.executeQuery(queryStr);
            
            while (rs.next()) {
                Pet tempPet = new Pet();
                tempPet.setId(rs.getInt("id"));
                tempPet.setPetname(rs.getString("petname"));
                tempPet.setPetcolor(rs.getString("petcolor"));
                tempPet.setBreed(rs.getString("breed"));
                petList.add(tempPet);
                LOGGER.info("Details added to list succesfully");
            }
           
            	stmt.close();
            
            

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        
			return petList;
		
        
    }

    @Override
    public boolean addPet(Pet pet) {
        LOGGER.debug("Adding is started");
        getConnection();
        PreparedStatement prestmt1;
        try {
            prestmt1 = conn
                    .prepareStatement("insert into pet (petname,petcolor,breed) values(?,?,?) ");
            LOGGER.info("SQL Query for inserting values");
            //prestmt1.setInt(1, pet.getId());
            prestmt1.setString(1, pet.getPetname());// 1�specifies�the�first�parameter�in�the�query
            LOGGER.error("petname should be String");
            prestmt1.setString(2, pet.getPetcolor());
            LOGGER.error("petcolor should be String");
            prestmt1.setString(3, pet.getBreed());
            LOGGER.error("breed should be String");
            prestmt1.executeUpdate();
            System.out.println("Inserted a record successfully");
            prestmt1.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public Pet findPet(int id) {
        LOGGER.debug("Finding pet is started");
        getConnection();
        String queryStr = "select * from pet where id='" + id + "'";
        LOGGER.info("SQL Query for finding pet");
        Statement stmt;
        try {
            stmt = conn.createStatement();

            // 3.Execute SQL Statements
            // 4.GET ResultSet
            ResultSet rs = stmt.executeQuery(queryStr);
            Pet tempEmp = new Pet();
            while (rs.next()) {
                tempEmp.setId(rs.getInt("id"));
                tempEmp.setPetname(rs.getString("petname"));
                tempEmp.setPetcolor(rs.getString("petcolor"));
                System.out.println(rs.getString("petcolor"));
                tempEmp.setBreed(rs.getString("breed"));

            }
            stmt.close();
            return tempEmp;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        LOGGER.debug("find pet is ended");
        return null;
    }

    public boolean deletePet(int id) throws SQLException {
        getConnection();
        PreparedStatement prestmt1 = conn
                .prepareStatement("delete from pet where id=?;");
        LOGGER.info("Delete query for deleting the record");
        prestmt1.setInt(1, id);
        prestmt1.executeUpdate();
        System.out.println("Deleted the record successfully");
        prestmt1.close();
        return true;
    }

    @Override
    public boolean update(Pet pet) {
        LOGGER.debug("update pet is started");
        getConnection();
       
        PreparedStatement prestmt1;
        try {
            prestmt1 = conn.prepareStatement(
                    "update pet set  petname=?, petcolor=?, breed=? where id ='"
                            + pet.getId() + "'");
            LOGGER.info("SQL Query for update");
            prestmt1.setInt(4, pet.getId());
            prestmt1.setString(1, pet.getPetname());
            LOGGER.error("petname should be String");
            prestmt1.setString(2, pet.getPetcolor());
            LOGGER.error("petcoclor should be String");
            prestmt1.setString(3, pet.getBreed());
            LOGGER.error("breed should be String");
            prestmt1.executeUpdate();
            System.out.println("A new record is successfully Upddated !");
            prestmt1.close();
            return true;
        } catch (Exception e) {
            return false;
        }
        
       
    }
    
}
