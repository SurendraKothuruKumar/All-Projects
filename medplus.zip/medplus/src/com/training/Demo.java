package com.training;



public  class Demo  {
   
   
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		byte bytevar=(byte)(44<<1);
		bytevar+=4;
		System.out.println(bytevar);
	}

}
