package com.training.springbootjpao2o.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Employee {
	@Id
	private int id;
	private String name;
	private String gender;
	private int salary;
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<Address> address;
	public Employee(int id, String name, String gender, int salary, Address address) {
		super();
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.salary = salary;
		this.address = (List<Address>) address;
	}
	public Employee() {
		super();
	}
	public Employee(int id, String name, String gender, int salary) {
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.salary = salary;
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public List<Address> getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = (List<Address>) address;
	}
	

}
